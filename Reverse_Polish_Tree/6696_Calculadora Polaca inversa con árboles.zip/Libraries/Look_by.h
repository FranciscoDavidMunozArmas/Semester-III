/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 28 de mayo de 2020 10:07:14
 * @function Declaration of Look_by
*/

#if !defined(__Look_by)
#define __Look_by

using namespace std;

class Look_by{
public:
	//int look_by_key(char* _key, char**_key_array);
	int look_by_key(char* _key, char** _key_array, int _index);
};

#endif
