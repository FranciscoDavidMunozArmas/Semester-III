/*
 * Universidad la Fuerzas Armadas ESPE
 *
 * @autor David Munoz & Daniela Orellana
 * @date Jueves, 28 de mayo de 2020 10:07:14
 * @function Declaration of Phone_verificator
*/

#if !defined(__Phone_verificator_h)
#define __Phone_verificator_h

using namespace std;

class Phone_verificator{
public:
	bool Phone_verify(char* phone);
};

#endif
