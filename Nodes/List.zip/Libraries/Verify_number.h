/***********************************************************************
 * Module:  Verify_number.h
 * Author:  USUARIO
 * Modified: mi�rcoles, 27 de mayo de 2020 15:07:22
 * Purpose: Declaration of the class Verify_number
 ***********************************************************************/

#if !defined(__Verify_number_h)
#define __Verify_number_h

using namespace std;

bool is_int_number(string string_1);
bool is_float_number(string string_1);

#endif
