/***********************************************************************
 * Module:  Array.h
 * Author:  USUARIO
 * Modified: jueves, 28 de mayo de 2020 19:07:11
 * Purpose: Declaration of the class Array
 ***********************************************************************/

#if !defined(__Look_by)
#define __Look_by

using namespace std;

class Look_by{
public:
	//int look_by_key(char* _key, char**_key_array);
	int look_by_key(char* _key, char** _key_array, int _index);
};

#endif
