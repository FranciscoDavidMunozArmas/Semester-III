/***********************************************************************
 * Module:  ID_verificator.h
 * Author:  USUARIO
 * Modified: mi�rcoles, 27 de mayo de 2020 15:07:22
 * Purpose: Declaration of the class ID_verificator
 ***********************************************************************/

#if !defined(__Phone_verificator_h)
#define __Phone_verificator_h

using namespace std;

class Phone_verificator{
public:
	bool Phone_verify(char* phone);
};

#endif
