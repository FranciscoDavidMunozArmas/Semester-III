#include <iostream>
#include <stdlib.h>
#include <stdio.h>

#include "List.cpp"
#include "Libraries/Menu.cpp"
#include "Libraries/Input.cpp"
#include "Libraries/To_number.cpp"

using namespace std;

/*template<class T>
class Node{
public:
    Node();
    Node(T data, Node* _node);

    void add_begin(T _data);
    void add_end(T _data);

    bool is_empty();

    T _get_data();
    void _set_data(T _data);

    Node* _get_node();
    void _set_node(Node* _node);

    void _print_node();

private:
    T data;
    Node* _next;
};

template<class T>
Node<T>::Node() {
    this->_next = NULL;
}

template<class T>
Node<T>::Node(T data, Node* _node) {
    this->data = data;
    this->_next = _node;
}

template<class T>
bool Node<T>::is_empty() {
    return (_next == NULL) ? true : false;
}

template<class T>
void Node<T>::add_begin(T _data) {
    if (is_empty()) {
        this->_next = new Node(_data, NULL);
    }
    else {
        Node<T>* aux = new Node();
        aux->_set_data(_data);
        aux->_set_node(_next);
        this->_next = aux;
    }
}

template<class T>
void Node<T>::add_end(T _data) {

    if (is_empty()) {
        this->_next = new Node(_data, NULL);
    }
    else {
        Node<T>* aux = new Node();
        Node<T>* aux_1 = new Node();
        Node<T>* aux_2 = new Node(_data, NULL);

        aux = this->_next;

        while (aux != NULL)
        {
            aux_1 = aux;
            aux = aux->_get_node();
        }

        aux_1->_set_node(aux_2);
    }
}

template<class T>
T Node<T>::_get_data() {
    return this->data;
}

template<class T>
void Node<T>::_set_data(T _data) {
    this->data = _data;
}

template<class T>
void Node<T>::_set_node(Node* _node) {
    this->_next = _node;
}

template<class T>
Node<T>* Node<T>::_get_node() {
    return this->_next;
}

template<class T>
void Node<T>::_print_node() {
    Node<T>* aux = new Node();
    aux = this->_next;
    while (aux != NULL) {
        cout << aux->_get_data() << " -> ";
        aux = aux->_next;
    }

    cout << "NULL" << endl;
}*/

int option();
template<typename T>
void menu(List<T> _list);

int option() {
    Menu _menu;
    char** _option = (char**)calloc(4, sizeof(char*));
    *(_option + 0) = "Introducir por cola";
    *(_option + 1) = "Introducir por cabeza";
    *(_option + 2) = "Imprimir";
    *(_option + 3) = "Salir";

    return _menu.options("Seleccione una opcion", _option , 4);
}

template<typename T>
void menu(List<T>* _list) {
    Input _input;
    char _answer;
    int i;

    switch (option()) {
    case 1:
        do {
            system("cls");
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _list->add_end(i);
            fflush(stdin);
            cout << "Quiere continuar? (S/N): ";
            scanf("%c", &_answer);
            fflush(stdin);
        } while (_answer != 'N' && _answer != 'n');
        break;
    case 2:
        do {
            system("cls");
            i = to_int(_input.input_int_number("Ingrese un numero: "));
            _list->add_begin(i);
            fflush(stdin);
            cout << "Quiere continuar? (S/N): ";
            scanf("%c", &_answer);
            fflush(stdin);
        } while (_answer != 'N' && _answer != 'n');
        break;
    case 3:
        system("cls");
        _list->_print_node();
        system("pause");
        break;
    default:
        exit(0);
        break;
    }
}

int main()
{
    List<int> _list;
    do {
        menu(&_list);
    } while (true);
    return 0;
}
